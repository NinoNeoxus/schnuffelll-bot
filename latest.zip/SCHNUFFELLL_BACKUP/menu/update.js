/**
 * Live Auto-Update Module for Schnuffelll Bot
 * Allows users to update their bot to latest version via Telegram
 * 
 * @author @schnuffelll
 * @version 6.0
 */

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const settings = require('../config.js');

// GitHub repository for updates
const UPDATE_CONFIG = {
    versionUrl: 'https://raw.githubusercontent.com/NinoNeoxus/schnuffelll-bot/main/version.json',
    downloadUrl: 'https://raw.githubusercontent.com/NinoNeoxus/schnuffelll-bot/main/latest.zip',
    localVersionFile: './version.json',
    backupDir: './backups',
    // Files/folders to PRESERVE during update (never overwrite)
    preserveList: [
        'config.js',
        'db/',
        'backups/',
        'node_modules/',
        'package-lock.json'
    ]
};

module.exports = (bot) => {
    const OWNER_ID = parseInt(settings.ownerId);

    console.log('[UPDATE] Module loaded - Owner ID:', OWNER_ID);

    // Helper: Get local version
    function getLocalVersion() {
        try {
            if (fs.existsSync(UPDATE_CONFIG.localVersionFile)) {
                return JSON.parse(fs.readFileSync(UPDATE_CONFIG.localVersionFile, 'utf8'));
            }
        } catch (e) {
            console.error('Error reading local version:', e);
        }
        return { version: '0.0', build: '0' };
    }

    // Helper: Get remote version from GitHub
    async function getRemoteVersion() {
        try {
            const response = await axios.get(UPDATE_CONFIG.versionUrl, {
                headers: { 'Cache-Control': 'no-cache' }
            });
            return response.data;
        } catch (e) {
            console.error('Error fetching remote version:', e.message);
            return null;
        }
    }

    // Helper: Compare versions (returns true if remote is newer)
    function isNewerVersion(local, remote) {
        const localParts = local.split('.').map(Number);
        const remoteParts = remote.split('.').map(Number);

        for (let i = 0; i < Math.max(localParts.length, remoteParts.length); i++) {
            const l = localParts[i] || 0;
            const r = remoteParts[i] || 0;
            if (r > l) return true;
            if (r < l) return false;
        }
        return false;
    }

    // Helper: Download update file
    async function downloadUpdate(url, destPath) {
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'arraybuffer'
        });

        fs.writeFileSync(destPath, response.data);
        return true;
    }

    // Helper: Create backup
    function createBackup() {
        const backupDir = UPDATE_CONFIG.backupDir;
        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir, { recursive: true });
        }

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupName = `backup_${timestamp}`;

        // Create backup of important files
        const filesToBackup = ['schnuffelll.js', 'start.js', 'version.json'];

        filesToBackup.forEach(file => {
            if (fs.existsSync(file)) {
                const dest = path.join(backupDir, `${backupName}_${file}`);
                fs.copyFileSync(file, dest);
            }
        });

        return backupName;
    }

    // Helper: Extract and apply update
    async function applyUpdate(zipPath) {
        return new Promise((resolve, reject) => {
            // Use tar to extract (works on Windows with recent versions)
            const extractCmd = process.platform === 'win32'
                ? `tar -xf "${zipPath}" --exclude="config.js" --exclude="db/*"`
                : `unzip -o "${zipPath}" -x "config.js" "db/*"`;

            exec(extractCmd, (error, stdout, stderr) => {
                if (error) {
                    // Fallback: try with PowerShell
                    const psCmd = `Expand-Archive -Path "${zipPath}" -DestinationPath "./temp_update" -Force`;
                    exec(psCmd, { shell: 'powershell.exe' }, (err2) => {
                        if (err2) {
                            reject(err2);
                        } else {
                            // Copy files except preserved ones
                            copyUpdateFiles('./temp_update');
                            resolve(true);
                        }
                    });
                } else {
                    resolve(true);
                }
            });
        });
    }

    // Helper: Copy update files while preserving config/db
    function copyUpdateFiles(sourceDir) {
        const preserveList = UPDATE_CONFIG.preserveList;

        function copyRecursive(src, dest) {
            if (!fs.existsSync(src)) return;

            const stats = fs.statSync(src);

            if (stats.isDirectory()) {
                if (!fs.existsSync(dest)) {
                    fs.mkdirSync(dest, { recursive: true });
                }

                fs.readdirSync(src).forEach(child => {
                    copyRecursive(path.join(src, child), path.join(dest, child));
                });
            } else {
                // Check if should preserve
                const relativePath = path.relative(sourceDir, src);
                const shouldPreserve = preserveList.some(p =>
                    relativePath.startsWith(p) || relativePath === p
                );

                if (!shouldPreserve) {
                    fs.copyFileSync(src, dest);
                }
            }
        }

        copyRecursive(sourceDir, './');

        // Cleanup temp folder
        fs.rmSync(sourceDir, { recursive: true, force: true });
    }

    // Helper: Restart bot
    function scheduleRestart() {
        console.log('[UPDATE] Scheduling restart in 3 seconds...');

        setTimeout(() => {
            // Try PM2 first
            exec('pm2 restart all', (err) => {
                if (err) {
                    // Fallback: exit and let systemd/pm2 restart
                    console.log('[UPDATE] Exiting for restart...');
                    process.exit(0);
                }
            });
        }, 3000);
    }

    // =================================================================
    // BOT COMMANDS
    // =================================================================

    // /version - Show current version
    bot.onText(/^\/version$/i, async (msg) => {
        const chatId = msg.chat.id;
        const local = getLocalVersion();

        const text = `
<b>📦 SCHNUFFELLL BOT</b>
<code>━━━━━━━━━━━━━━━━━━━━━━</code>

<blockquote>
🏷️ Version: <b>${local.version}</b>
🔢 Build: <code>${local.build}</code>
📅 Release: ${local.releaseDate || 'Unknown'}
</blockquote>

<i>Ketik /update untuk cek update terbaru</i>
`;

        bot.sendMessage(chatId, text, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    });

    // /changelog - Show changelog
    bot.onText(/^\/changelog$/i, async (msg) => {
        const chatId = msg.chat.id;
        const local = getLocalVersion();

        let changelogText = '📋 <b>CHANGELOG</b>\n\n';

        if (local.changelog && Array.isArray(local.changelog)) {
            changelogText += local.changelog.map((item, i) => `${item}`).join('\n');
        } else {
            changelogText += '<i>Tidak ada changelog</i>';
        }

        bot.sendMessage(chatId, changelogText, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    });

    // /update - Check and install updates
    bot.onText(/^\/update$/i, async (msg) => {
        const chatId = msg.chat.id;
        const userId = parseInt(msg.from.id);

        console.log('[UPDATE] /update command received from:', userId, 'Owner:', OWNER_ID);

        // Owner only for update
        if (userId !== OWNER_ID) {
            console.log('[UPDATE] Access denied - not owner');
            return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ!');
        }

        console.log('[UPDATE] Access granted - checking for updates...');
        const wait = await bot.sendMessage(chatId, '🔍 Mengecek update...', { reply_to_message_id: msg.message_id });

        try {
            const local = getLocalVersion();
            const remote = await getRemoteVersion();

            if (!remote) {
                return bot.editMessageText('❌ Gagal mengecek update. Cek koneksi internet.', {
                    chat_id: chatId,
                    message_id: wait.message_id
                });
            }

            const hasUpdate = isNewerVersion(local.version, remote.version);

            if (!hasUpdate) {
                return bot.editMessageText(`✅ <b>Bot sudah versi terbaru!</b>

📦 Versi: <b>${local.version}</b>
🔢 Build: <code>${local.build}</code>`, {
                    chat_id: chatId,
                    message_id: wait.message_id,
                    parse_mode: 'HTML'
                });
            }

            // Show update available
            let changelogText = '';
            if (remote.changelog && Array.isArray(remote.changelog)) {
                changelogText = remote.changelog.slice(0, 5).join('\n');
            }

            const updateText = `
🆕 <b>UPDATE TERSEDIA!</b>

<blockquote>
📦 Versi Baru: <b>${remote.version}</b>
📅 Release: ${remote.releaseDate || 'Unknown'}

<b>Changelog:</b>
${changelogText}
</blockquote>

⚠️ <b>PENTING:</b>
• Config.js akan tetap aman
• Database (db/) akan tetap aman
• Bot akan restart otomatis

Ketik <code>/update confirm</code> untuk mulai update.
`;

            await bot.editMessageText(updateText, {
                chat_id: chatId,
                message_id: wait.message_id,
                parse_mode: 'HTML'
            });

        } catch (err) {
            console.error('Update check error:', err);
            bot.editMessageText('❌ Error: ' + err.message, {
                chat_id: chatId,
                message_id: wait.message_id
            });
        }
    });

    // /update confirm - Actually install the update
    bot.onText(/^\/update confirm$/i, async (msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (userId !== OWNER_ID) {
            return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ!');
        }

        const statusMsg = await bot.sendMessage(chatId, `
🔄 <b>MEMULAI UPDATE...</b>

⏳ Step 1/4: Mengunduh update...
⬜ Step 2/4: Membuat backup...
⬜ Step 3/4: Menginstall update...
⬜ Step 4/4: Restart bot...
`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });

        try {
            // Step 1: Download
            const remote = await getRemoteVersion();
            if (!remote) throw new Error('Gagal mengambil info update');

            const downloadUrl = remote.downloadUrl || UPDATE_CONFIG.downloadUrl;
            const zipPath = './update_temp.zip';

            await downloadUpdate(downloadUrl, zipPath);

            // Update status
            await bot.editMessageText(`
🔄 <b>MEMULAI UPDATE...</b>

✅ Step 1/4: Download selesai
⏳ Step 2/4: Membuat backup...
⬜ Step 3/4: Menginstall update...
⬜ Step 4/4: Restart bot...
`, { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });

            // Step 2: Backup
            const backupName = createBackup();

            await bot.editMessageText(`
🔄 <b>MEMULAI UPDATE...</b>

✅ Step 1/4: Download selesai
✅ Step 2/4: Backup dibuat (${backupName})
⏳ Step 3/4: Menginstall update...
⬜ Step 4/4: Restart bot...
`, { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });

            // Step 3: Apply update
            await applyUpdate(zipPath);

            // Cleanup zip
            if (fs.existsSync(zipPath)) {
                fs.unlinkSync(zipPath);
            }

            await bot.editMessageText(`
🔄 <b>MEMULAI UPDATE...</b>

✅ Step 1/4: Download selesai
✅ Step 2/4: Backup dibuat
✅ Step 3/4: Update diinstall
⏳ Step 4/4: Restart bot...
`, { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });

            // Step 4: Final message before restart
            await bot.editMessageText(`
✅ <b>UPDATE BERHASIL!</b>

📦 Versi: <b>${remote.version}</b>
📅 Date: ${remote.releaseDate}

🔄 Bot akan restart dalam 3 detik...

<i>Jika bot tidak aktif, restart manual dari panel.</i>
`, { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });

            // Schedule restart
            scheduleRestart();

        } catch (err) {
            console.error('Update error:', err);
            bot.editMessageText(`❌ <b>UPDATE GAGAL!</b>

Error: ${err.message}

Bot tetap berjalan dengan versi lama.`, {
                chat_id: chatId,
                message_id: statusMsg.message_id,
                parse_mode: 'HTML'
            });
        }
    });

};
