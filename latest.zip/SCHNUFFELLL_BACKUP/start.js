const axios = require("axios"); // <--- INI TAMBAHAN
const fs = require("fs");
const fetch = require("node-fetch");
const unzipper = require("unzipper");
const os = require("os");
const { exec } = require("child_process");

const usersFile = "./db/users/users.json";
const adminfile = "./db/users/adminID.json";
const premiumUsersFile = "./db/users/premiumUsers.json";
// Perbaikan: path file resellerUsers salah tulis (ressellerUsers -> resellerUsers)
const ressUsersFile = "./db/users/resellerUsers.json";

const privateUsers = JSON.parse(fs.readFileSync("./db/users/private/privateID.json"));

const settings = require("./config.js");
const config = require("./config.js");

const developer = settings.dev;
const pp = settings.pp;
const ppVid = settings.ppVid;

let ownerUsers = [];
let premiumUsers = [];
let ressUsers = [];

let users = [];
let userState = {};
let userUploads = {}
let web2zipSessions = {}

if (fs.existsSync(adminfile)) {
  ownerUsers = JSON.parse(fs.readFileSync(adminfile));
}

if (fs.existsSync(premiumUsersFile)) {
  premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
}

if (fs.existsSync(ressUsersFile)) {
  ressUsers = JSON.parse(fs.readFileSync(ressUsersFile));
}

const now = new Date();
const waktu = now.toLocaleTimeString("id-ID", { timeZone: "Asia/Jakarta" });

module.exports = (bot) => {
  bot.onText(/^\/cek$/, async (msg) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    let targetUser = msg.from;
    if (msg.reply_to_message) targetUser = msg.reply_to_message.from;

    const userId = targetUser.id;
    const firstName = targetUser.first_name || "User";

    try {
      await bot.sendMessage(
        userId,
        "Start bot ulang!"
      );

      // simpen id ke database      
      let users = JSON.parse(fs.readFileSync(usersFile));
      if (!users.includes(userId)) {
        users.push(userId);
        fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
      }

      // kirim ke grup
      await bot.sendMessage(
        chatId,
        `✅ [${firstName}](tg://user?id=${userId}) sudah start bot! silahkan create.`,
        { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
      );
    } catch (err) {
      await bot.sendMessage(
        chatId,
        `❌ [${firstName}](tg://user?id=${userId}) belum start bot di private chat. dilarang create!`,
        { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
      );
    }
  });

  // =======================================================
  // === FITUR BARU: LIST & DELETE TOKEN LISENSI (dari GitHub) ===
  // =======================================================

  // Objek lisensi ini disalin dari schnuffelll.js
  // Ganti token ini dengan token BARU yang sudah lu buat ulang
  const license = {
    githubToken: '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', // <-- GANTI TOKEN INI
    githubRepo: 'NinoNeoxus/DB',
    githubPath: 'token'
  };

  /**
   * Fungsi helper untuk mengambil data token dan SHA dari GitHub
   */
  async function getGithubTokenData() {
    const { githubToken, githubRepo, githubPath } = license;
    const apiUrl = `https://api.github.com/repos/${githubRepo}/contents/${githubPath}`;
    const headers = {
      'Authorization': `token ${githubToken}`,
      'Accept': 'application/vnd.github.v3+json'
    };

    try {
      const response = await axios.get(apiUrl, { headers });
      // Kontennya base64, kita decode
      const content = Buffer.from(response.data.content, 'base64').toString('utf-8');
      const sha = response.data.sha;
      // File 'token' itu isinya array JSON, jadi kita parse
      const tokens = JSON.parse(content);
      return { tokens, sha };
    } catch (error) {
      if (error.response && error.response.status === 404) {
        // File tidak ada, kembalikan array kosong dan SHA null
        console.log("File 'token' di GitHub tidak ditemukan. Buat file baru dulu.");
        return { tokens: [], sha: null };
      }
      console.error("Gagal mengambil data dari GitHub:", error.response ? error.response.data : error.message);
      throw new Error("Gagal mengambil data dari GitHub.");
    }
  }

  /**
   * Fungsi helper untuk meng-update file token di GitHub
   */
  async function updateGithubTokenData(tokensArray, sha, commitMessage) {
    const { githubToken, githubRepo, githubPath } = license;
    const apiUrl = `https://api.github.com/repos/${githubRepo}/contents/${githubPath}`;
    const headers = {
      'Authorization': `token ${githubToken}`,
      'Accept': 'application/vnd.github.v3+json'
    };

    // Ubah array baru jadi JSON string, lalu encode ke base64
    const newContent = JSON.stringify(tokensArray, null, 2);
    const newContentBase64 = Buffer.from(newContent).toString('base64');

    const body = {
      message: commitMessage,
      content: newContentBase64,
      sha: sha // SHA wajib ada untuk update file yang sudah ada
    };

    try {
      await axios.put(apiUrl, body, { headers });
      return true;
    } catch (error) {
      console.error("Gagal meng-update data ke GitHub:", error.response ? error.response.data : error.message);
      throw new Error("Gagal meng-update data ke GitHub.");
    }
  }


  // --- 1. FITUR LIST TOKEN TELEGRAM ---
  bot.onText(/^\/listtoken$/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    // Cek Owner (ownerUsers udah ada di atas file start.js)
    if (!ownerUsers.includes(userId)) {
      return bot.sendMessage(chatId, "❌ Perintah ini khusus Owner Bot!");
    }

    try {
      const waitMsg = await bot.sendMessage(chatId, "⏳ Mengambil daftar token dari GitHub...", { reply_to_message_id: msg.message_id });

      const { tokens } = await getGithubTokenData();

      if (!tokens || tokens.length === 0) {
        return bot.editMessageText("ℹ️ Tidak ada token lisensi yang tersimpan di GitHub.", {
          chat_id: chatId,
          message_id: waitMsg.message_id
        });
      }

      let responseMessage = "🔑 Daftar Token Lisensi Telegram di GitHub:\n\n";
      tokens.forEach((token, index) => {
        // Masking token untuk keamanan
        const maskedToken = `${token.substring(0, 10)}...${token.substring(token.length - 4)}`;
        responseMessage += `*${index + 1}.* \`${maskedToken}\`\n`;
      });

      responseMessage += "\n(Token bot Telegram yang diizinkan)\nGunakan /deltoken <nomor> untuk menghapus.";

      bot.editMessageText(responseMessage, {
        chat_id: chatId,
        message_id: waitMsg.message_id,
        parse_mode: "Markdown"
      });

    } catch (error) {
      bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    }
  });


  // --- 2. FITUR DELETE TOKEN TELEGRAM ---
  bot.onText(/^\/deltoken(?:\s+(.+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    const indexStr = match[1];

    // Cek Owner
    if (!ownerUsers.includes(userId)) {
      return bot.sendMessage(chatId, "❌ Perintah ini khusus Owner Bot!");
    }

    if (!indexStr || isNaN(parseInt(indexStr))) {
      return bot.sendMessage(chatId, "❌ Format salah. Gunakan: /deltoken <nomor_urut>\nCek nomor urut di /listtoken.", { reply_to_message_id: msg.message_id });
    }

    const listNumber = parseInt(indexStr);
    const arrayIndex = listNumber - 1; // Konversi ke index array (mulai dari 0)

    try {
      const waitMsg = await bot.sendMessage(chatId, `⏳ Menghapus token nomor ${listNumber} dari GitHub...`, { reply_to_message_id: msg.message_id });

      // 1. Ambil data DAN SHA saat ini
      const { tokens: currentTokens, sha } = await getGithubTokenData();

      if (!currentTokens || currentTokens.length === 0) {
        return bot.editMessageText("❌ Gagal: Tidak ada token untuk dihapus.", {
          chat_id: chatId,
          message_id: waitMsg.message_id
        });
      }

      // Cek nomornya valid
      if (arrayIndex < 0 || arrayIndex >= currentTokens.length) {
        return bot.editMessageText(`❌ Gagal: Nomor token ${listNumber} tidak valid. (Hanya ada 1 sampai ${currentTokens.length})`, {
          chat_id: chatId,
          message_id: waitMsg.message_id
        });
      }

      // SHA wajib ada buat update
      if (!sha) {
        return bot.editMessageText(`❌ Gagal: Tidak bisa mendapatkan SHA file. Tidak dapat mengupdate.`, {
          chat_id: chatId,
          message_id: waitMsg.message_id
        });
      }

      // 2. Hapus token dari array
      const tokenToDelete = currentTokens[arrayIndex];
      const newTokens = currentTokens.filter((_, index) => index !== arrayIndex); // Buat array baru tanpa token itu

      // 3. Update kembali ke GitHub
      await updateGithubTokenData(newTokens, sha, `Bot: Hapus token (index ${listNumber})`);

      // Gunakan panjang tokenToDelete untuk masking, bukan variabel token yang tidak ada
      const maskedToken = `${tokenToDelete.substring(0, 10)}...${tokenToDelete.substring(tokenToDelete.length - 4)}`;

      bot.editMessageText(`✅ Berhasil menghapus token:\n\`${maskedToken}\``, {
        chat_id: chatId,
        message_id: waitMsg.message_id,
        parse_mode: "Markdown"
      });

    } catch (error) {
      bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    }
  });

  // =======================================================
  // === AKHIR FITUR BARU =================================
  // =======================================================

  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    let targetUser = msg.from;
    const senderId = targetUser.id;

    // runtime vps
    const vpsUptime = os.uptime();
    const vpsUptimeStr = `${Math.floor(vpsUptime / 86400)}d ${Math.floor((vpsUptime % 86400) / 3600)}h ${Math.floor((vpsUptime % 3600) / 60)}m`;

    const status = ownerUsers.includes(userId)
      ? "Owner"
      : premiumUsers.includes(userId)
        ? "Premium"
        : ressUsers.includes(userId)
          ? "Reseller"
          : "User";

    let userSave = JSON.parse(fs.readFileSync(usersFile));
    if (!userSave.includes(senderId)) {
      userSave.push(senderId);
      fs.writeFileSync(usersFile, JSON.stringify(userSave, null, 2));
    }

    if (fs.existsSync(usersFile)) {
      users = JSON.parse(fs.readFileSync(usersFile));
    }
    const total = users.length;

    // --- FITUR DYNAMIC MAIN MENU ---
    const ownerSettingsPath = "./db/owner_settings.json";
    let ownerSettings = {
      menuType: "text",
      menuMedia: "",
      menuCaption: "Menu Default"
    };

    if (fs.existsSync(ownerSettingsPath)) {
      try {
        ownerSettings = JSON.parse(fs.readFileSync(ownerSettingsPath));
      } catch (e) {
        console.error("Gagal load owner settings:", e);
      }
    }

    // === SIMPLE WELCOME TEXT (untuk handle batasan Telegram) ===
    const welcomeText = `
<b>⚡ 𝐒𝐂𝐇𝐍𝐔𝐅𝐅𝐄𝐋𝐋𝐋 𝐁𝐎𝐓 ⚡</b>
<code>━━━━━━━━━━━━━━━━━━━━━━</code>
<b>🎉 Version 6.0 | Panel Manager</b>
<code>━━━━━━━━━━━━━━━━━━━━━━</code>

👋 <i>Assalamu'alaikum,</i> <b>@${msg.from.username || msg.from.first_name}</b>!

<blockquote>
📊 <b>INFO</b>
┣ 🎭 Status: <b>${status}</b>
┣ 👥 Users: <b>${total}</b>
┣ ⏰ ${waktu}
┗ 📡 Uptime: <b>${vpsUptimeStr}</b>
</blockquote>

${ownerSettings.menuCaption || "🔽 <i>Klik tombol dibawah untuk membuka menu:</i>"}
`;

    // Simple keyboard dengan 1 tombol Menu saja
    const simpleKeyboard = {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "📋 𝐌𝐄𝐍𝐔", callback_data: "openmainmenu" }
          ],
          [
            { text: "🛒 BUY SCRIPT @schnuffelll", url: "t.me/schnuffelll" }
          ]
        ],
      },
    };

    // Logic pengiriman berdasarkan tipe menu dengan SMART error handling
    const sendWithMedia = async () => {
      const mediaUrl = ownerSettings.menuMedia || '';
      const mediaType = ownerSettings.menuType || 'text';

      // Jika tidak ada media atau type text, langsung kirim text
      if (!mediaUrl || mediaType === 'text') {
        try {
          await bot.sendMessage(chatId, welcomeText, simpleKeyboard);
        } catch (e) {
          console.error('Error sending text:', e.message);
        }
        return;
      }

      // Auto-detect actual file type dari URL extension
      const urlLower = mediaUrl.toLowerCase();
      const isLikelyImage = urlLower.match(/\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i);
      const isLikelyVideo = urlLower.match(/\.(mp4|mov|avi|mkv|webm)(\?.*)?$/i);
      const isLikelyAudio = urlLower.match(/\.(mp3|ogg|wav|m4a|flac)(\?.*)?$/i);

      // Determine which method to use
      let sendMethod = 'text'; // default fallback

      if (mediaType === 'audio') {
        sendMethod = 'audio';
      } else if (mediaType === 'video') {
        if (isLikelyImage) {
          console.log('WARNING: menuType is video but URL looks like image, using sendPhoto');
          sendMethod = 'photo';
        } else if (isLikelyAudio) {
          console.log('WARNING: menuType is video but URL looks like audio, using sendAudio');
          sendMethod = 'audio';
        } else {
          sendMethod = 'video';
        }
      } else if (mediaType === 'image') {
        if (isLikelyVideo) {
          console.log('WARNING: menuType is image but URL looks like video, using sendVideo');
          sendMethod = 'video';
        } else if (isLikelyAudio) {
          console.log('WARNING: menuType is image but URL looks like audio, using sendAudio');
          sendMethod = 'audio';
        } else {
          sendMethod = 'photo';
        }
      }

      try {
        if (sendMethod === 'photo') {
          await bot.sendPhoto(chatId, mediaUrl, { caption: welcomeText, ...simpleKeyboard });
        } else if (sendMethod === 'video') {
          await bot.sendVideo(chatId, mediaUrl, { caption: welcomeText, ...simpleKeyboard });
        } else if (sendMethod === 'audio') {
          // Kirim text dulu, lalu audio (audio tidak support caption panjang)
          await bot.sendMessage(chatId, welcomeText, simpleKeyboard);
          await bot.sendAudio(chatId, mediaUrl, {
            title: '🎵 Schnuffelll Bot',
            performer: '@schnuffelll'
          });
        } else {
          await bot.sendMessage(chatId, welcomeText, simpleKeyboard);
        }
      } catch (err) {
        console.error('Error sending media:', err.message);

        // Try opposite method if first one failed
        if (sendMethod === 'photo') {
          try {
            console.log('Retrying as video...');
            await bot.sendVideo(chatId, mediaUrl, { caption: welcomeText, ...simpleKeyboard });
            return;
          } catch (e2) {
            console.error('Video retry also failed:', e2.message);
          }
        } else if (sendMethod === 'video') {
          try {
            console.log('Retrying as photo...');
            await bot.sendPhoto(chatId, mediaUrl, { caption: welcomeText, ...simpleKeyboard });
            return;
          } catch (e2) {
            console.error('Photo retry also failed:', e2.message);
          }
        }

        // Final fallback ke text saja
        try {
          await bot.sendMessage(chatId, welcomeText + '\n\n⚠️ _Media gagal dimuat, cek URL di /pengaturan_', { ...simpleKeyboard, parse_mode: 'Markdown' });
        } catch (e) {
          console.error('Error sending fallback message:', e.message);
        }
      }
    };

    sendWithMedia();
  });

  // === HANDLER UNTUK TOMBOL "MENU" - Kirim message baru dengan menu lengkap ===
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "openmainmenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const chatId = callbackQuery.message.chat.id;
      const userId = callbackQuery.from.id.toString();

      // Load user data untuk status
      const status = ownerUsers.includes(userId)
        ? "Owner"
        : premiumUsers.includes(userId)
          ? "Premium"
          : ressUsers.includes(userId)
            ? "Reseller"
            : "User";

      const menuText = `
<b>📋 𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔</b>
<code>━━━━━━━━━━━━━━━━━━━━━━</code>

<blockquote>
👤 <b>@${callbackQuery.from.username || callbackQuery.from.first_name}</b>
🎭 Status: <b>${status}</b>
📦 Version: <b>6.0</b>
</blockquote>

🔽 <i>Pilih menu yang tersedia:</i>
`;

      const fullMenuKeyboard = {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔐 PRIVATE", callback_data: "privmenu" },
              { text: "🧩 PANEL", callback_data: "createpanel" },
            ],
            [
              { text: "⚙️ INSTALL", callback_data: "installmenu" },
              { text: "☁️ VPS", callback_data: "cvpsmenu" },
              { text: "🔧 OTHER", callback_data: "othermenu" }
            ],
            [
              { text: "🛡️ INSTALL PROTECT", callback_data: "installprotectmenu" },
              { text: "🗑️ UNINSTALL", callback_data: "uninstallprotectmenu" }
            ],
            [
              { text: "🛡️ GROUP GUARD", callback_data: "guardmenu" },
              { text: "⚔️ RPG GAME", callback_data: "rpgmenu" }
            ],
            [
              { text: "👑 OWNER MENU", callback_data: "ownermenu" },
              { text: "⚙️ PENGATURAN", callback_data: "pengaturanbot" }
            ],
            [
              { text: "❌ TUTUP", callback_data: "closemenu" }
            ]
          ],
        },
      };

      // Kirim sebagai message BARU (bukan edit) untuk avoid batasan Telegram
      bot.sendMessage(chatId, menuText, fullMenuKeyboard);
    }
  });

  // Handler untuk tutup menu
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "closemenu") {
      bot.answerCallbackQuery(callbackQuery.id, { text: "Menu ditutup!" });
      // Hapus message menu
      bot.deleteMessage(callbackQuery.message.chat.id, callbackQuery.message.message_id).catch(() => { });
    }
  });

  // Handler untuk tombol Pengaturan (callback)
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "pengaturanbot") {
      bot.answerCallbackQuery(callbackQuery.id);
      const userId = callbackQuery.from.id.toString();
      // Cek owner
      if (!ownerUsers.includes(userId)) {
        return bot.sendMessage(callbackQuery.message.chat.id, "❌ Khusus Owner!");
      }
      // Trigger command /pengaturan secara manual atau kasih info
      bot.sendMessage(callbackQuery.message.chat.id, "🔧 Gunakan command `/pengaturan` untuk mengubah tampilan bot.", { parse_mode: "Markdown" });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "createpanel") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `\`\`\`
╭──✧ <b>ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ</b> ✧
│ ⪼ Version : 1.0.0
│ ⪼ Owner : @${developer}
│ ⪼ Type : Public
╰────────────⧽

╭──✧ ᴏᴡɴᴇʀ ᴍᴇɴᴜ ✧
│ ⪼ /addprem <id>
│ ⪼ /delprem <id>
│ ⪼ /address <id>
│ ⪼ /delress <id>
╰────────────⧽

╭──✧ ᴘʀᴇᴍɪᴜᴍ ᴍᴇɴᴜ ✧
│ ⪼ /listsrv
│ ⪼ /listsrvoff
│ ⪼ /listadmin
│ ⪼ /deladm <id>
│ ⪼ /delusroff
│ ⪼ /delsrv <id>
│ ⪼ /delsrvoff
│ ⪼ /totalserver
│ ⪼ /servercpu
╰────────────⧽

╭──✧ ʀᴇꜱᴇʟʟᴇʀ ᴍᴇɴᴜ ✧
│ ⪼ /1gb-/10gb nama,id
│ ⪼ /unli nama,id
│ ⪼ /cadp nama,id
╰────────────⧽
\`\`\``;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⿻ ᴘʀɪᴠᴀᴛᴇ ᴍᴇɴᴜ", callback_data: "privmenu" },
              { text: "<<", callback_data: "back" },
            ],
            [
              { text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "ownermenu" }
            ],
            [
              { text: "ꜱᴇʀᴠᴇʀ 2", callback_data: "serverdua" },
              { text: "ꜱᴇʀᴠᴇʀ 3", callback_data: "servertiga" },
              { text: "ꜱᴇʀᴠᴇʀ 4", callback_data: "serverempat" }
            ],
            [
              { text: "ꜱᴇʀᴠᴇʀ 5", callback_data: "serverlima" }
            ]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "privmenu") {
      bot.answerCallbackQuery(callbackQuery.id);

      const userId = callbackQuery.from.id.toString();

      if (!privateUsers.includes(userId)) {
        bot.answerCallbackQuery(callbackQuery.id, {
          text: "❌ Akses ditolak! Menu ini hanya untuk User Private",
          show_alert: true
        });
        return;
      }

      const text = `\`\`\`
╭──✧ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ✧
│ ⪼ Version : 1.0.0
│ ⪼ Owner : @${developer}
│ ⪼ Type : Private
╰────────────⧽

╭──✧ ᴏᴡɴᴇʀ ᴘʀɪᴠᴀᴛᴇ ✧
│ ⪼ /pinfo
│ ⪼ /addpremp <id>
│ ⪼ /addressp <id>
╰────────────⧽

╭──✧ ᴘʀᴇᴍɪᴜᴍ ᴘʀɪᴠᴀᴛᴇ ✧
│ ⪼ /srvlist
│ ⪼ /srvofflist
│ ⪼ /admlist
│ ⪼ /srvdel <id>
│ ⪼ /srvoffdel
│ ⪼ /totalsrv
│ ⪼ /srvcpu
╰────────────⧽

╭──✧ ʀᴇꜱᴇʟʟᴇʀ ᴘʀɪᴠᴀᴛᴇ ✧
│ ⪼ /1gbp-/10gbp nama,id
│ ⪼ /cunli nama,id
│ ⪼ /cadmin nama,id
╰────────────⧽
\`\`\``;

      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "<<", callback_data: "back" },
              { text: "🧩 ᴄʀᴇᴀᴛᴇ ᴘᴀɴᴇʟ", callback_data: "createpanel" },
            ],
            [
              { text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "ownermenu" }
            ]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "serverdua") {

      const userId = callbackQuery.from.id.toString();
      const isResellerV2 = JSON.parse(fs.readFileSync("./db/users/version/resellerV2.json"));

      if (!isResellerV2.includes(userId)) {
        return;
      }
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `<blockquote>┌─⧼ <b>ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ</b> ⧽
├ ⬡ Version : 2.0.0
├ ⬡ Owner : @${developer}
├ ⬡ Language : JavaScript
╰─────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴏᴡɴᴇʀ ᴠ2</b> ⧽
├ /addowner — Add Owner
├ /delowner — Hapus Owner
├ /addpremv2 — Add Premium V2
├ /delpremv2 — Del Premium V2
╰──────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴘʀᴇᴍɪᴜᴍ ᴠ2</b> ⧽
├ /addressv2 — Add Reseller V2
├ /delressv2 — Del Reseller V2
╰──────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴀᴅᴍɪɴ ᴠ 2</b> ⧽
├ /listsrv2
├ /listadmin2
├ /delsrv2
╰──────────────

┌─⧼ <b>ʀᴇꜱᴇʟʟᴇʀ ᴍᴇɴᴜ ᴠ 2</b> ⧽ 
├ /1gbv2-/10gbv2 nama,id
├ /unliv2 nama,id
├ /cadpv2 nama,id
╰──────────────
</blockquote>`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⿻ ᴘʀɪᴠᴀᴛᴇ ᴍᴇɴᴜ", callback_data: "privmenu" },
              { text: "🧩 ᴄʀᴇᴀᴛᴇ ᴘᴀɴᴇʟ", callback_data: "createpanel" },
            ],
            [
              { text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "ownermenu" }
            ],
            [
              { text: "<<", callback_data: "back" },
              { text: "ꜱᴇʀᴠᴇʀ 3", callback_data: "servertiga" },
              { text: "ꜱᴇʀᴠᴇʀ 4", callback_data: "serverempat" }
            ],
            [
              { text: "ꜱᴇʀᴠᴇʀ 5", callback_data: "serverlima" }
            ]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "servertiga") {

      const userId = callbackQuery.from.id.toString();
      const isResellerV3 = JSON.parse(fs.readFileSync("./db/users/version/resellerV3.json"));

      if (!isResellerV3.includes(userId)) {
        return;
      }
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `<blockquote>┌─⧼ <b>ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ</b> ⧽
├ ⬡ Version : 3.0.0
├ ⬡ Owner : @${developer}
├ ⬡ Language : JavaScript
╰─────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴏᴡɴᴇʀ ᴠ3</b> ⧽
├ /addowner — Add Owner
├ /delowner — Hapus Owner
├ /addpremv3 — Add Premium V3
├ /delpremv3 — Del Premium V3
╰──────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴘʀᴇᴍɪᴜᴍ ᴠ3</b> ⧽
├ /addressv3 — Add Reseller V3
├ /delressv3 — Del Reseller V3
╰──────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴀᴅᴍɪɴ ᴠ3</b> ⧽
├ /listsrv3
├ /listadmin3
├ /delsrv3
╰──────────────

┌─⧼ <b>ʀᴇꜱᴇʟʟᴇʀ ᴍᴇɴᴜ ᴠ 3</b> ⧽ 
├ /1gbv3-/10gbv3 nama,id
├ /unliv3 nama,id
├ /cadpv3 nama,id
╰──────────────
</blockquote>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⿻ ᴘʀɪᴠᴀᴛᴇ ᴍᴇɴᴜ", callback_data: "privmenu" },
              { text: "🧩 ᴄʀᴇᴀᴛᴇ ᴘᴀɴᴇʟ", callback_data: "createpanel" },
            ],
            [
              { text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "ownermenu" }
            ],
            [
              { text: "ꜱᴇʀᴠᴇʀ 2", callback_data: "serverdua" },
              { text: "<<", callback_data: "back" },
              { text: "ꜱᴇʀᴠᴇʀ 4", callback_data: "serverempat" }
            ],
            [
              { text: "ꜱᴇʀᴠᴇʀ 5", callback_data: "serverlima" }
            ]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "serverempat") {

      const userId = callbackQuery.from.id.toString();
      const isResellerV4 = JSON.parse(fs.readFileSync("./db/users/version/resellerV4.json"));

      if (!isResellerV4.includes(userId)) {
        return;
      }
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `<blockquote>┌─⧼ <b>ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ</b> ⧽
├ ⬡ Version : 4.0.0
├ ⬡ Owner : @${developer}
├ ⬡ Language : JavaScript
╰─────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴏᴡɴᴇʀ ᴠ 4</b> ⧽
├ /addowner — Add Owner
├ /delowner — Hapus Owner
├ /addpremv4 — Add Premium V4
├ /delpremv4 — Del Premium V4
╰──────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴘʀᴇᴍɪᴜᴍ ᴠ 4</b> ⧽
├ /address4 — Add Reseller V4
├ /delressv4 — Del Reseller V4
╰──────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴀᴅᴍɪɴ ᴠ 4</b> ⧽
├ /listsrv4
├ /listadmin4
├ /delsrv4
╰──────────────

┌─⧼ <b>ʀᴇꜱᴇʟʟᴇʀ ᴍᴇɴᴜ ᴠ 4</b> ⧽ 
├ /1gbv4-/10gbv4 nama,id
├ /unliv4 nama,id
├ /cadpv4 nama,id
╰──────────────
</blockquote>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⿻ ᴘʀɪᴠᴀᴛᴇ ᴍᴇɴᴜ", callback_data: "privmenu" },
              { text: "🧩 ᴄʀᴇᴀᴛᴇ ᴘᴀɴᴇʟ", callback_data: "createpanel" },
            ],
            [
              { text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "ownermenu" }
            ],
            [
              { text: "ꜱᴇʀᴠᴇʀ 2", callback_data: "serverdua" },
              { text: "ꜱᴇʀᴠᴇʀ 3", callback_data: "servertiga" },
              { text: "<<", callback_data: "back" }
            ],
            [
              { text: "ꜱᴇʀᴠᴇʀ 5", callback_data: "serverlima" }
            ]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "serverlima") {

      const userId = callbackQuery.from.id.toString();
      const isResellerV5 = JSON.parse(fs.readFileSync("./db/users/version/resellerV5.json"));

      if (!isResellerV5.includes(userId)) {
        return;
      }
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `<blockquote>┌─⧼ <b>ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ</b> ⧽
├ ⬡ Version : 5.0.0
├ ⬡ Owner : @${developer}
├ ⬡ Language : JavaScript
╰─────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴏᴡɴᴇʀ ᴠ 5</b> ⧽
├ /addowner — Add Owner
├ /delowner — Hapus Owner
├ /addpremv5 — Add Premium V5
├ /delpremv5 — Del Premium V5
╰──────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴘʀᴇᴍɪᴜᴍ ᴠ 5</b> ⧽
├ /address5 — Add Reseller V5
├ /delressv5 — Del Reseller V5
╰──────────────

┌─⧼ <b>ᴍᴇɴᴜ ᴀᴅᴍɪɴ ᴠ 5</b> ⧽
├ /listsrv5
├ /listadmin5
├ /delsrv5
╰──────────────

┌─⧼ <b>ʀᴇꜱᴇʟʟᴇʀ ᴍᴇɴᴜ ᴠ 5</b> ⧽ 
├ /1gbv5-/10gbv5 nama,id
├ /unliv5 nama,id
├ /cadpv5 nama,id
╰──────────────
</blockquote>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⿻ ᴘʀɪᴠᴀᴛᴇ ᴍᴇɴᴜ", callback_data: "privmenu" },
              { text: "🧩 ᴄʀᴇᴀᴛᴇ ᴘᴀɴᴇʟ", callback_data: "createpanel" },
            ],
            [
              { text: "ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "ownermenu" }
            ],
            [
              { text: "ꜱᴇʀᴠᴇʀ 2", callback_data: "serverdua" },
              { text: "ꜱᴇʀᴠᴇʀ 3", callback_data: "servertiga" },
              { text: "ꜱᴇʀᴠᴇʀ 4", callback_data: "serverempat" }
            ],
            [
              { text: "<<", callback_data: "back" }
            ]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "ownermenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `\`\`\`
╭───✧ ᴏᴡɴᴇʀ ʙᴏᴛ ✧
│ ⪼ /addtoken <token> 
│ ⪼ /listtoken
│ ⪼ /deltoken <nomor>
│ ⪼ /addtk <id>
│ ⪼ /addpt <id>
│ ⪼ /addown <id>
│ ⪼ /addpr <id>
╰────────────⧽

╭──✧ ᴋʜᴜꜱᴜꜱ ᴅᴇᴠ ✧
│ ⪼ /setcd
│ ⪼ /backup
│ ⪼ /setting
│ ⪼ /reqpair
╰────────────⧽

╭──✧ ᴀᴅᴅ ᴜꜱᴇʀ ɪᴅ ✧
│ ⪼ /addpublic
│ ⪼ /addprivate
╰────────────⧽

╭──✧ ᴏᴡɴᴇʀ ᴘᴀɴᴇʟ ✧
│ ⪼ /address <id>
│ ⪼ /delress <id>
│ ⪼ /addprem <id>
│ ⪼ /delprem <id>
╰────────────⧽
\`\`\``;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⿻ ᴘʀɪᴠᴀᴛᴇ ᴍᴇɴᴜ", callback_data: "privmenu" },
              { text: "🧩 ᴄʀᴇᴀᴛᴇ ᴘᴀɴᴇʟ", callback_data: "createpanel" },
            ],
            [
              { text: "⚙️ ɪɴꜱᴛᴀʟʟ ᴍᴇɴᴜ", callback_data: "installmenu" },
              { text: "<<", callback_data: "back" },
              { text: "ᴏᴛʜᴇʀ ᴍᴇɴᴜ", callback_data: "othermenu" }
            ],
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "othermenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🔧 <b>OTHER MENU</b>  ║
╚══════════════════════════════════╝

<blockquote expandable>
┌─「 📥 <b>DOWNLOAD MENU</b> 」
│
│ <code>/tiktok [link]</code>
│   └ Download TikTok (Video/Audio)
│   └ Pilih HD/SD/MP3
│ <code>/ytmp3 [link]</code>
│   └ Download YouTube ke MP3
│ <code>/ytmp4 [link]</code>
│   └ Download YouTube ke MP4
│ <code>/spotify [judul]</code>
│   └ Download musik Spotify
│ <code>/download</code>
│   └ Lihat semua fitur download
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 🔄 <b>CONVERT MENU</b> 」
│
│ <code>/tourl</code> (reply file)
│   └ Upload file ke Catbox URL
│ <code>/shortlink [url]</code>
│   └ Perpendek link apapun
│ <code>/qc [teks]</code>
│   └ Buat quote chat sticker
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 🔍 <b>STALK MENU</b> 」
│
│ <code>/stalkig [user]</code>
│   └ Stalk akun Instagram
│ <code>/stalktiktok [user]</code>
│   └ Stalk akun TikTok
│ <code>/stalkyt [user]</code>
│   └ Stalk channel YouTube
│ <code>/stalkgithub [user]</code>
│   └ Stalk akun GitHub
│ <code>/stalkroblox [user]</code>
│   └ Stalk akun Roblox
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 🎨 <b>MEDIA MENU</b> 」
│
│ <code>/pin [query]</code>
│   └ Cari gambar Pinterest
│ <code>/brat [teks]</code>
│   └ Buat stiker brat style
│ <code>/iqc [jam|batt|carrier|pesan]</code>
│   └ Buat screenshot iPhone palsu
│ <code>/xnxx [title|url_gambar]</code>
│   └ Buat meme xnxx style
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 🔮 <b>PRIMBON MENU</b> 」
│
│ <code>/artinama [nama]</code>
│   └ Cek arti nama kamu
│ <code>/jodoh [nama1|nama2]</code>
│   └ Cek kecocokan jodoh
│ <code>/lacakip [ip]</code>
│   └ Lacak lokasi dari IP
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 🤖 <b>AI MENU</b> 」
│
│ <code>/ai</code>
│   └ Aktifkan mode AI chat
│ <code>/stopai</code>
│   └ Matikan mode AI chat
│
└───────────────────────
</blockquote>

<i>💡 Kirim link TikTok langsung untuk auto-download!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "📥 DOWNLOAD", callback_data: "downloadmenu" },
              { text: "🔍 STALK", callback_data: "stalkmenu" }
            ],
            [
              { text: "⿻ ᴘʀɪᴠᴀᴛᴇ ᴍᴇɴᴜ", callback_data: "privmenu" },
              { text: "🧩 ᴄʀᴇᴀᴛᴇ ᴘᴀɴᴇʟ", callback_data: "createpanel" },
            ],
            [
              { text: "⚙️ ɪɴꜱᴛᴀʟʟ ᴍᴇɴᴜ", callback_data: "installmenu" },
              { text: "👑 ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "ownermenu" },
              { text: "<<", callback_data: "back" }
            ]
          ],
        },
      });
    }
  });

  // Download Menu Sub-callback
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "downloadmenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  📥 <b>DOWNLOAD CENTER</b>  ║
╚══════════════════════════════════╝

<b>🎬 VIDEO DOWNLOAD</b>

<code>/tiktok [link]</code>
└ Download video TikTok tanpa watermark
└ Support: Video HD, SD, dan Audio MP3
└ Auto-detect: Kirim link langsung!

<code>/ytmp4 [link]</code>
└ Download video YouTube ke MP4
└ Support sampai 1080p HD

<b>🎵 AUDIO DOWNLOAD</b>

<code>/ytmp3 [link]</code>
└ Download YouTube ke format MP3
└ Kualitas tinggi, cepat

<code>/spotify [judul/link]</code>
└ Download musik dari Spotify
└ Auto cari & download

<b>🖼️ GAMBAR</b>

<code>/pin [query]</code>
└ Cari & download gambar Pinterest
└ Navigasi dengan tombol ⬅️ ➡️

<code>/tourl</code> (reply foto/video)
└ Upload file ke Catbox
└ Dapat link permanen

<b>💡 TIPS PENGGUNAAN:</b>
• TikTok: Kirim link langsung, bot auto detect
• YouTube: Paste link penuh dari browser
• Spotify: Bisa pakai judul atau link

<i>© 2025 Schnuffelll Download Center</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🎬 TikTok", switch_inline_query_current_chat: "/tiktok " },
              { text: "📹 YouTube", switch_inline_query_current_chat: "/ytmp4 " }
            ],
            [
              { text: "🎵 Spotify", switch_inline_query_current_chat: "/spotify " },
              { text: "🖼️ Pinterest", switch_inline_query_current_chat: "/pin " }
            ],
            [
              { text: "⬅️ KEMBALI", callback_data: "othermenu" }
            ]
          ],
        },
      });
    }
  });

  // Stalk Menu Sub-callback
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "stalkmenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🔍 <b>STALK CENTER</b>  ║
╚══════════════════════════════════╝

<b>📱 SOCIAL MEDIA STALK</b>

<code>/stalkig [username]</code>
├ Stalk akun Instagram
├ Info: Nama, Bio, Follower, Following
├ Bonus: Post terbaru + Foto profil
└ Contoh: <code>/stalkig cristiano</code>

<code>/stalktiktok [username]</code>
├ Stalk akun TikTok
├ Info: Nama, Bio, Verified status
├ Stats: Followers, Following, Likes, Videos
└ Contoh: <code>/stalktiktok mrbeast</code>

<code>/stalkyt [channel]</code>
├ Stalk channel YouTube
├ Info: Nama, Subscriber, Total Video
├ Bonus: Video terbaru
└ Contoh: <code>/stalkyt pewdiepie</code>

<b>💻 DEVELOPER STALK</b>

<code>/stalkgithub [username]</code>
├ Stalk akun GitHub
├ Info: Repos, Followers, Following
├ Bonus: Company, Location, Bio
└ Contoh: <code>/stalkgithub torvalds</code>

<b>🎮 GAMING STALK</b>

<code>/stalkroblox [username]</code>
├ Stalk akun Roblox
├ Info: ID, Friends, Followers
├ Bonus: Badges & Avatar
└ Contoh: <code>/stalkroblox builderman</code>

<i>💡 Semua stalk menampilkan foto profil!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "📸 Instagram", switch_inline_query_current_chat: "/stalkig " },
              { text: "🎵 TikTok", switch_inline_query_current_chat: "/stalktiktok " }
            ],
            [
              { text: "📹 YouTube", switch_inline_query_current_chat: "/stalkyt " },
              { text: "💻 GitHub", switch_inline_query_current_chat: "/stalkgithub " }
            ],
            [
              { text: "⬅️ KEMBALI", callback_data: "othermenu" }
            ]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "installmenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `\`\`\`
╭──✧ ɪɴꜱᴛᴀʟʟ ᴍᴇɴᴜ ✧
│ ⪼ /install <option>
╰────────────⧽

╭──✧ ᴜɴɪɴꜱᴛᴀʟʟ ᴍᴇɴᴜ ✧
│ ⪼ /uninstallpanel <option>
│ ⪼ /uninstalltema <ipvps,pwvps>
│ ⪼ /uninstalltemabg <ipvps,pwvps>
╰────────────⧽

╭──✧ ᴄʀᴇᴀᴛᴇ ɴᴏᴅᴇ ✧
│ ⪼ /createnode
│ ⪼ /swings <ipvps,pwvps,token> atau /swings (interaktif)
│ ⪼ /debug <ipvps,pwvps> atau /debug (interaktif)
│ ⪼ /cwings <ipvps,pwvps>
╰────────────⧽

╭──✧ ʜᴀᴄᴋʙᴀᴄᴋ ᴘᴀɴᴇʟ ✧
│ ⪼ /usrpanel <ipvps,pwvps>
│ ⪼ /usrpasswd <ipvps,pwvps>
│ ⪼ /hbpanel <ipvps,pwvps>
│ ⪼ /clearall <ipvps,pwvps>
│ ⪼ /clearstorage <ipvps,pwvps>
╰────────────⧽

╭──✧ ʀᴜɴᴛɪᴍᴇ ᴠᴘꜱ ✧
│ ⪼ /spekvps <ipvps,pwvps>
│ ⪼ /cpuvps <ipvps,pwvps>
│ ⪼ /runtimevps <ipvps,pwvps>
│ ⪼ /refreshvps <ipvps,pwvps>
│ ⪼ /setpwvps <ipvps,pwlama,pwbaru>
│ ⪼ /rebuild <ipvps,pwvps> ← NEW!
╰────────────⧽

╭──✧ ꜱᴜʙᴅᴏᴍᴀɪɴ ✧
│ ⪼ /listsubdo
│ ⪼ /subdo <name,ipvps>
│ ⪼ /upsubdo <nomor>
│ ⪼ /addsubdo
╰────────────⧽

╭──✧ ɪɴꜱᴛᴀʟʟ ᴛᴇᴍᴀ ✧
│ ⪼ /installdepend (wajib)
│ ⪼ /installtemanebula <ipvps,pwvps>
│ ⪼ /installtemabg <ipvps,pwvps>
│ ⪼ /uninstalltema <ipvps,pwvps>
╰────────────⧽
\`\`\`
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⿻ ᴘʀɪᴠᴀᴛᴇ ᴍᴇɴᴜ", callback_data: "privmenu" },
              { text: "🧩 ᴄʀᴇᴀᴛᴇ ᴘᴀɴᴇʟ", callback_data: "createpanel" },
            ],
            [
              { text: "<<", callback_data: "back" },
              { text: "👑 ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "ownermenu" },
              { text: "ᴏᴛʜᴇʀ ᴍᴇɴᴜ", callback_data: "othermenu" }
            ],
            [
              { text: "ᴄʀᴇᴀᴛᴇ ᴠᴘꜱ", callback_data: "cvpsmenu" },
              { text: "🔄 ʀᴇʙᴜɪʟᴅ ᴠᴘꜱ", callback_data: "rebuildmenu" }
            ]
          ],
        },
      });
    }
  });

  // Guard Menu Callback - FIXED: Uses editMessageText properly
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "guardmenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🛡️ <b>GROUP GUARD v3.0</b>  ║
╠══════════════════════════════════╣
║  Ultimate Protection System  ║
╚══════════════════════════════════╝

<blockquote expandable>
┌─「 🛡️ <b>ANTI FEATURES</b> 」
│
│ ✅ Anti-Link (hapus link)
│ ✅ Anti-Spam (deteksi spam)
│ ✅ Anti-Bot (block bot masuk)
│ ✅ Anti-Sticker / Anti-GIF
│ ✅ Anti-Forward
│ ✅ Anti-Arab / Anti-Chinese
│ ✅ Anti-Virtex (teks crash)
│ ✅ Anti-Flood (pesan beruntun)
│ ✅ Anti-Tagall (mention spam)
│ ✅ Anti-Toxic (kata kasar)
│ ✅ Anti-Photo / Video / Audio
│ ✅ Anti-Document / Voice
│ ✅ Anti-Inline Bot
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 👮 <b>MODERASI</b> 」
│
│ /kick /ban /unban
│ /mute /unmute
│ /warn /unwarn
│ /promote /demote
│ /pin /unpin /del
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 ⚙️ <b>SETTINGS</b> 」
│
│ /setwelcome - Set welcome msg
│ /setgoodbye - Set goodbye msg
│ /addfilter - Blacklist kata
│ /addreply - Auto reply
│
└───────────────────────
</blockquote>

<i>💡 Ketik /guard di grup untuk panel lengkap!</i>
<i>💡 Ketik /guardhelp untuk bantuan!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🛡️ ANTI FITUR", callback_data: "guard_anti" },
              { text: "⚙️ SETTINGS", callback_data: "guard_settings" }
            ],
            [
              { text: "👮 MODERASI", callback_data: "guard_mod" },
              { text: "📝 FILTER", callback_data: "guard_filter" }
            ],
            [
              { text: "🤖 AUTO REPLY", callback_data: "guard_autoreply" },
              { text: "❓ HELP", callback_data: "guard_help" }
            ],
            [
              { text: "⬅️ KEMBALI", callback_data: "back" }
            ]
          ],
        },
      });
    }
  });

  // Guard Sub-menus
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "guard_anti") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🛡️ <b>ANTI FEATURES</b>  ║
╚══════════════════════════════════╝

┌─「 🔒 <b>PROTEKSI OTOMATIS</b> 」
│
│ <b>Basic Protection:</b>
│ • Anti-Link - Hapus link otomatis
│ • Anti-Spam - Deteksi pesan spam
│ • Anti-Bot - Block bot join grup
│ • Anti-Forward - Hapus pesan forward
│
│ <b>Media Protection:</b>
│ • Anti-Sticker - Hapus sticker
│ • Anti-GIF - Hapus animasi
│ • Anti-Photo / Video / Audio
│ • Anti-Document / Voice
│
│ <b>Advanced Protection:</b>
│ • Anti-Virtex - Block teks crash
│ • Anti-Flood - Block pesan beruntun
│ • Anti-Tagall - Block tag massal
│ • Anti-Toxic - Filter kata kasar
│ • Anti-Arab/Chinese - Filter teks
│ • Anti-Inline - Block inline bot
│
└───────────────────────

<i>💡 Aktifkan via /guard di grup!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "guardmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "guard_settings") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  ⚙️ <b>SETTINGS MENU</b>  ║
╚══════════════════════════════════╝

┌─「 🔧 <b>GROUP SETTINGS</b> 」
│
│ <b>Lock/Unlock:</b>
│ • /guard → Toggle Lock Grup
│
│ <b>Welcome/Goodbye:</b>
│ • /setwelcome &lt;pesan&gt;
│ • /setgoodbye &lt;pesan&gt;
│
│ <b>Variables:</b>
│ • {user} - Mention user
│ • {group} - Nama grup
│ • {id} - User ID
│ • {count} - Jumlah member
│
│ <b>Lainnya:</b>
│ • Slowmode (via panel)
│ • Warn Limit (via panel)
│ • Only Admin Mode
│
└───────────────────────

<i>💡 Buka /guard untuk panel lengkap!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "guardmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "guard_mod") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  👮 <b>MODERASI COMMANDS</b>  ║
╚══════════════════════════════════╝

┌─「 🔨 <b>USER MANAGEMENT</b> 」
│
│ <b>Kick &amp; Ban:</b>
│ • /kick - Kick user (reply/id)
│ • /ban - Ban permanen
│ • /unban &lt;id&gt; - Unban user
│
│ <b>Mute:</b>
│ • /mute [menit] - Mute user
│ • /unmute - Unmute user
│
│ <b>Warning:</b>
│ • /warn - Beri warning
│ • /unwarn - Reset warning
│
├─「 👑 <b>ADMIN</b> 」
│
│ • /promote - Jadikan admin
│ • /demote - Cabut admin
│
├─「 📌 <b>PIN</b> 」
│
│ • /pin - Pin pesan (reply)
│ • /unpin - Unpin semua
│
├─「 🗑️ <b>DELETE</b> 」
│
│ • /del - Hapus pesan (reply)
│
└───────────────────────

<i>💡 Semua command support REPLY!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "guardmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "guard_filter") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  📝 <b>WORD FILTER</b>  ║
╚══════════════════════════════════╝

┌─「 🔤 <b>BADWORD FILTER</b> 」
│
│ Blacklist kata-kata terlarang!
│ Pesan dengan kata terfilter
│ akan otomatis dihapus.
│
│ <b>Commands:</b>
│ • /addfilter &lt;kata&gt;
│   Tambah kata ke blacklist
│
│ • /delfilter &lt;kata&gt;
│   Hapus dari blacklist
│
│ • /listfilter
│   Lihat semua filter
│
│ • /clearfilter
│   Hapus semua filter
│
└───────────────────────

<i>💡 Filter case-insensitive!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "guardmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "guard_autoreply") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🤖 <b>AUTO REPLY</b>  ║
╚══════════════════════════════════╝

┌─「 💬 <b>BALASAN OTOMATIS</b> 」
│
│ Bot akan membalas otomatis
│ ketika ada trigger tertentu!
│
│ <b>Commands:</b>
│ • /addreply trigger|balasan
│   Contoh: /addreply halo|Hai juga!
│
│ • /delreply &lt;trigger&gt;
│   Hapus auto reply
│
│ • /listreply
│   Lihat semua auto reply
│
└───────────────────────

<i>💡 Trigger case-insensitive!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "guardmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "guard_help") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  ❓ <b>GUARD HELP</b>  ║
╚══════════════════════════════════╝

<b>🛡️ CARA PAKAI:</b>

1️⃣ Tambahkan bot ke grup
2️⃣ Jadikan bot sebagai ADMIN
3️⃣ Ketik /guard di grup
4️⃣ Aktifkan fitur yang diinginkan

<b>📌 TIPS:</b>

• Bot HARUS jadi admin!
• Berikan permission penuh
• Semua moderasi support reply
• Ketik /guardhelp untuk bantuan

<b>🔗 SUPPORT:</b>
• @schnuffelll

<i>© 2025 Schnuffelll Guard</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "guardmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "cvpsmenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔═══════════════════════════════╗
║     ☁️ 𝐕𝐏𝐒 𝐌𝐀𝐍𝐀𝐆𝐄𝐑     ║
╚═══════════════════════════════╝

┌─「 🚀 𝗖𝗥𝗘𝗔𝗧𝗘 𝗩𝗣𝗦 」
│
│  /createvps <option>
│  /statusdo <option>
│
├─「 📊 𝗦𝗧𝗔𝗧𝗨𝗦 𝗩𝗣𝗦 」
│
│  /cekdata <dropletId>
│  /listvps <option>
│  /delvps <dropletId>
│
└───────────────────────
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⿻ ᴘʀɪᴠᴀᴛᴇ ᴍᴇɴᴜ", callback_data: "privmenu" },
              { text: "🧩 ᴄʀᴇᴀᴛᴇ ᴘᴀɴᴇʟ", callback_data: "createpanel" },
            ],
            [
              { text: "⚙️ ɪɴꜱᴛᴀʟʟ ᴍᴇɴᴜ", callback_data: "installmenu" },
              { text: "👑 ᴏᴡɴᴇʀ ᴍᴇɴᴜ", callback_data: "ownermenu" },
              { text: "ᴏᴛʜᴇʀ ᴍᴇɴᴜ", callback_data: "othermenu" }
            ],
            [
              { text: "<<", callback_data: "back" }
            ]
          ],
        },
      });
    }
  });

  // Rebuild VPS Menu Callback
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "rebuildmenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🔄 <b>REBUILD VPS</b>  ║
╚══════════════════════════════════╝

<blockquote>
┌─「 📋 <b>INFORMASI</b> 」
│
│ Fitur ini akan <b>REINSTALL</b> OS VPS
│ ke Ubuntu 22.04 dengan live log.
│
│ <b>⚠️ WARNING:</b>
│ • Semua data di VPS akan HILANG
│ • Proses membutuhkan 5-15 menit
│ • VPS akan reboot beberapa kali
│
└───────────────────────
</blockquote>

<b>🔧 CARA PAKAI:</b>
• Mode Langsung: <code>/rebuild ipvps,pwvps</code>
• Mode Interaktif: <code>/rebuild</code>

<i>💡 Setelah rebuild, password VPS mungkin reset!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⬅️ KEMBALI", callback_data: "installmenu" }
            ]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "back") {
      bot.answerCallbackQuery(callbackQuery.id);

      const userId = callbackQuery.from.id.toString();

      // runtime vps
      const vpsUptime = os.uptime();
      const vpsUptimeStr = `${Math.floor(vpsUptime / 86400)}d ${Math.floor((vpsUptime % 86400) / 3600)}h ${Math.floor((vpsUptime % 3600) / 60)}m`;

      const status = ownerUsers.includes(userId)
        ? "Owner"
        : premiumUsers.includes(userId)
          ? "Premium"
          : ressUsers.includes(userId)
            ? "Reseller"
            : "User";

      if (fs.existsSync(usersFile)) {
        users = JSON.parse(fs.readFileSync(usersFile));
      }
      const total = users.length;

      const menuText = `
╔═══════════════════════════════════╗
║  🌟 𝐒𝐂𝐇𝐍𝐔𝐅𝐅𝐄𝐋𝐋𝐋 𝐁𝐎𝐓 𝐕𝟐.𝟎  🌟  ║
╚═══════════════════════════════════╝

👋 𝘼𝙨𝙨𝙖𝙡𝙖𝙢𝙪'𝙖𝙡𝙖𝙞𝙠𝙪𝙢, <b>@${callbackQuery.from.username || callbackQuery.from.first_name}</b>!

┌─「 📊 𝗜𝗡𝗙𝗢 」
│  🎭 Status: <b>${status}</b>
│  👥 User: <b>${total}</b>
│  ⏰ ${waktu} | 📡 ${vpsUptimeStr}
└───────────────────────

<blockquote expandable>
🕌 <b>𝗞𝗔𝗧𝗔 𝗠𝗨𝗧𝗜𝗔𝗥𝗔 𝗜𝗦𝗟𝗔𝗠</b> 🕌

<i>"Perumpamaan orang yang menginfakkan hartanya di jalan Allah seperti sebutir biji yang menumbuhkan tujuh tangkai, pada setiap tangkai ada seratus biji. Allah melipatgandakan bagi siapa yang Dia kehendaki."</i>
— QS. Al-Baqarah: 261

🤲 <i>"Tangan di atas lebih baik daripada tangan di bawah. Tangan di atas adalah tangan yang memberi."</i>
— HR. Bukhari & Muslim

💎 <i>"Sedekah tidak akan mengurangi harta. Tidak ada orang yang memberi maaf melainkan Allah akan menambah kemuliaannya."</i>
— HR. Muslim

🌙 <i>"Lindungilah dirimu dari api neraka walau hanya dengan bersedekah separuh kurma, jika tidak mampu maka dengan perkataan yang baik."</i>
— HR. Bukhari & Muslim

🌟 <b>Mari berbagi kebaikan!</b>
<i>Ilmu yang bermanfaat, rezeki yang halal, dan kebaikan sekecil apapun akan menjadi amal jariyah yang pahalanya terus mengalir.</i>
</blockquote>

💫 <i>Barakallahu fiikum</i>
`;

      bot.editMessageText(menuText, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔐 PRIVATE", callback_data: "privmenu" },
              { text: "🧩 PANEL", callback_data: "createpanel" },
            ],
            [
              { text: "⚙️ INSTALL", callback_data: "installmenu" },
              { text: "☁️ VPS", callback_data: "cvpsmenu" },
              { text: "🔧 OTHER", callback_data: "othermenu" }
            ],
            [
              { text: "🛡️ INSTALL PROTECT", callback_data: "installprotectmenu" },
              { text: "🗑️ UNINSTALL", callback_data: "uninstallprotectmenu" }
            ],
            [
              { text: "🛡️ GROUP GUARD", callback_data: "guardmenu" },
              { text: "⚔️ RPG GAME", callback_data: "rpgmenu" }
            ],
            [
              { text: "👑 OWNER MENU", callback_data: "ownermenu" }
            ],
            [
              { text: "🛒 BUY SCRIPT @schnuffelll", url: "https://t.me/schnuffelll" }
            ]
          ]
        }
      });
    }
  });

  // RPG Menu Callback - CYBERPUNK EDITION
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "rpgmenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════════════════════╗
║  🌆 <b>CYBERPUNK SURVIVAL RPG v3.0</b>  ║
╠══════════════════════════════════════════════════╣
║  <i>Neo-Jakarta 2077 - Survive the Neon</i>  ║
╚══════════════════════════════════════════════════╝

<blockquote expandable>
┌─「 🎭 <b>CYBERPUNK CLASSES</b> 」
│
│ 🖥️ <b>Netrunner</b> - Elite Hacker
│ 🔫 <b>Solo</b> - Mercenary Combat
│ 🔧 <b>Techie</b> - Tech Genius
│ 💉 <b>Medtech</b> - Street Doctor
│ 🏍️ <b>Nomad</b> - Wasteland Survivor
│ 💼 <b>Corpo</b> - Ex-Corporate Agent
│ 🎭 <b>Fixer</b> - Info Broker
│ 🛹 <b>Street Kid</b> - City Native
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 🌡️ <b>SURVIVAL SYSTEM</b> 」
│
│ 🍖 Hunger - Lapar
│ 💧 Thirst - Haus
│ ⚡ Stamina - Energi
│ 🧠 Sanity - Kewarasan
│ 🦾 Humanity - Cyberware
│
│ <i>Low stats = debuff & HP drain!</i>
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 🌆 <b>NEO-JAKARTA DISTRICTS</b> 」
│
│ 🌃 Gang Alley (Lv.1+)
│ 🏪 Neon Market (Lv.5+)
│ 🏢 Corpo Plaza (Lv.10+)
│ ☢️ Cyber Wasteland (Lv.15+)
│ 🕳️ Underground Bunker (Lv.20+)
│ 💻 Cyberspace (Lv.30+)
│ 🛸 Orbital Station (Lv.40+)
│ 🏰 Mega Tower (Lv.50+)
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 ⚡ <b>QUICK COMMANDS</b> 」
│
│ <code>.daftar [nama] [class]</code> - Create
│ <code>.profile</code> - View stats
│ <code>.survival</code> - Survival status
│ <code>.adv [location]</code> - Adventure
│ <code>.inventory</code> - Check items
│ <code>.shop</code> - Black market
│ <code>.gacha</code> - Lucky draw
│ <code>.daily</code> - Daily reward
│ <code>.rpghelp</code> - Full help
│
└───────────────────────
</blockquote>

<i>🌆 "Welcome to Night City, choom. 
Don't let the corpo rats flatline you."</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🎭 CLASSES", callback_data: "rpg_char" },
              { text: "🌆 LOCATIONS", callback_data: "rpg_adv" }
            ],
            [
              { text: "🎒 INVENTORY", callback_data: "rpg_inv" },
              { text: "🏪 SHOP", callback_data: "rpg_shop" }
            ],
            [
              { text: "🌡️ SURVIVAL", callback_data: "rpg_survival" },
              { text: "🎰 GACHA", callback_data: "rpg_gacha" }
            ],
            [
              { text: "🏆 LEADERBOARD", callback_data: "rpg_lb" },
              { text: "❓ HELP", callback_data: "rpg_help" }
            ],
            [
              { text: "⬅️ KEMBALI", callback_data: "back" }
            ]
          ],
        },
      });
    }
  });

  // RPG Sub-menus - CYBERPUNK EDITION
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "rpg_char") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🎭 <b>CYBERPUNK CLASSES</b>  ║
╚══════════════════════════════════╝

<i>"Choose your path in the neon jungle."</i>

┌─「 🎮 <b>CREATE CHARACTER</b> 」
│
│ <code>.daftar [nama] [class]</code>
│
│ <b>Contoh:</b>
│ <code>.daftar V netrunner</code>
│
└───────────────────────

┌─「 🎭 <b>AVAILABLE CLASSES</b> 」
│
│ 🖥️ <b>Netrunner</b>
│   └ Elite Hacker, Magic tinggi
│   └ Skills: ICE Breaker, Neural Spike
│
│ 🔫 <b>Solo</b>
│   └ Mercenary, Combat Expert
│   └ Skills: Bullet Time, Rage Mode
│
│ 🔧 <b>Techie</b>
│   └ Tech Genius, Craftsman
│   └ Skills: Drone Deploy, EMP Blast
│
│ 💉 <b>Medtech</b>
│   └ Street Doctor, Support
│   └ Skills: Combat Stim, Revive
│
│ 🏍️ <b>Nomad</b>
│   └ Wasteland Survivor
│   └ Skills: Scavenge, Survival Instinct
│
│ 💼 <b>Corpo</b>
│   └ Ex-Corporate Agent
│   └ Skills: Bribe, Corpo Connections
│
│ 🎭 <b>Fixer</b>
│   └ Info Broker, Negotiator
│   └ Skills: Insight, Black Market
│
│ 🛹 <b>Street Kid</b>
│   └ City Native, Street Wise
│   └ Skills: Pickpocket, Street Rep
│
└───────────────────────

<b>Commands:</b>
<code>.profile</code> - View stats
<code>.survival</code> - Survival status
<code>.skills</code> - View skills
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "rpgmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "rpg_adv") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🌆 <b>NEO-JAKARTA DISTRICTS</b>  ║
╚══════════════════════════════════╝

<i>"The city never sleeps, and neither do its demons."</i>

┌─「 🗺️ <b>EXPLORE LOCATIONS</b> 」
│
│ 🌃 <b>Gang Alley</b> (Lv.1+)
│   └ Street Punk, Junkie, Pickpocket
│   └ BOSS: Gang Leader
│
│ 🏪 <b>Neon Market</b> (Lv.5+)
│   └ Black Dealer, Booster, Scammer
│   └ BOSS: Yakuza Boss
│
│ 🏢 <b>Corpo Plaza</b> (Lv.10+)
│   └ Corpo Guard, Security Drone
│   └ BOSS: Corpo Executive
│
│ ☢️ <b>Cyber Wasteland</b> (Lv.15+)
│   └ Mutant, Radiated Beast, Scavenger
│   └ BOSS: Wasteland Warlord
│
│ 🕳️ <b>Underground Bunker</b> (Lv.20+)
│   └ Lab Experiment, Maelstrom Gang
│   └ BOSS: Dr. Experiment
│
│ 💻 <b>Cyberspace</b> (Lv.30+)
│   └ Rogue AI, Virus, Data Ghost
│   └ BOSS: Blackwall Demon
│
│ 🛸 <b>Orbital Station</b> (Lv.40+)
│   └ Space Marine, Alien Parasite
│   └ BOSS: Orbital Commander
│
│ 🏰 <b>Mega Tower</b> (Lv.50+)
│   └ Elite Guard, Cyborg Assassin
│   └ BOSS: Corporate Overlord
│
└───────────────────────

<b>Command:</b>
<code>.adv gang_alley</code>
<code>.adv corpo_plaza</code>

<i>💀 12% chance ketemu BOSS!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "rpgmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "rpg_inv") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🎒 <b>INVENTORY SYSTEM</b>  ║
╚══════════════════════════════════╝

<i>"Your stash, your lifeline."</i>

┌─「 📦 <b>COMMANDS</b> 」
│
│ <code>.inventory</code> - Check stash
│ <code>.use [item]</code> - Use consumable
│ <code>.equip [item]</code> - Equip gear
│ <code>.sell [item] [qty]</code> - Sell item
│
└───────────────────────

┌─「 📊 <b>ITEM TYPES</b> 」
│
│ 💊 <b>Consumables</b>
│   └ Stimpacks, Food, Drinks
│   └ Restore HP, MP, Survival
│
│ ⚔️ <b>Weapons</b>
│   └ Pistols, SMGs, Katanas
│   └ Bonus ATK stats
│
│ 🛡️ <b>Armor</b>
│   └ Jackets, Vests, Helmets
│   └ Bonus DEF & HP
│
│ 💍 <b>Accessories</b>
│   └ Cyberdecks, Optics
│   └ Special bonuses
│
│ 🦾 <b>Augmentations</b>
│   └ Cybernetic upgrades
│   └ Permanent stat boosts
│
│ 🔩 <b>Materials</b>
│   └ Components, Scrap
│   └ For crafting/selling
│
└───────────────────────

<i>💡 Equip gear untuk bonus stats!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "rpgmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "rpg_shop") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🏪 <b>BLACK MARKET</b>  ║
╚══════════════════════════════════╝

<i>"What do you need, choom? I got everything."</i>

┌─「 💰 <b>COMMANDS</b> 」
│
│ <code>.shop</code> - Browse market
│ <code>.buy [item]</code> - Purchase
│ <code>.buy [item] [qty]</code> - Buy bulk
│ <code>.sell [item] [qty]</code> - Sell items
│
└───────────────────────

┌─「 💊 <b>CONSUMABLES</b> 」
│
│ Cheap Stimpack - €$50
│ Military Stimpack - €$200
│ Protein Bar - €$30
│ Synthetic Ramen - €$80
│ Purified Water - €$25
│ Energy Drink - €$60
│
└───────────────────────

┌─「 ⚔️ <b>WEAPONS</b> 」
│
│ Rusty Knife - €$100
│ Street Pistol - €$500
│ Combat Shotgun - €$2000
│ Katana - €$3000
│ Smart SMG - €$5000
│
└───────────────────────

┌─「 🛡️ <b>ARMOR</b> 」
│
│ Worn Jacket - €$200
│ Kevlar Vest - €$1000
│ Combat Helmet - €$800
│ Tech Jacket - €$3000
│
└───────────────────────

<i>💵 Earn €$ from adventures!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "rpgmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "rpg_lb") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🏆 <b>NEO-JAKARTA LEGENDS</b>  ║
╚══════════════════════════════════╝

<b>📊 Command:</b>
<code>.leaderboard</code>

Menampilkan Top 10 mercs dengan:
• 📈 Level tertinggi
• 💀 Total kills
• 👑 Boss defeats

<i>💀 "Legends never die, choom."</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "rpgmenu" }]
          ],
        },
      });
    }
  });

  // RPG Survival Menu
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "rpg_survival") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🌡️ <b>SURVIVAL SYSTEM</b>  ║
╚══════════════════════════════════╝

┌─「 📊 <b>SURVIVAL STATS</b> 」
│
│ 🍖 <b>Hunger</b> - Kebutuhan makan
│   └ Low = ATK/SPD debuff
│   └ <code>.eat [item]</code>
│
│ 💧 <b>Thirst</b> - Kebutuhan minum
│   └ Low = DEF/MP debuff
│   └ <code>.drink [item]</code>
│
│ ⚡ <b>Stamina</b> - Energi
│   └ Low = Can't adventure
│   └ <code>.rest [jam]</code>
│
│ 🧠 <b>Sanity</b> - Kewarasan
│   └ Low = Random debuffs
│   └ Rest atau pulang ke rumah
│
│ 🦾 <b>Humanity</b> - Kemanusiaan
│   └ Berkurang saat pasang cyberware
│   └ Low = Cyberpsychosis risk
│
└───────────────────────

┌─「 ⚠️ <b>WARNINGS</b> 」
│
│ • Stats turun seiring waktu
│ • Adventure menguras stamina
│ • Low stats = HP drain!
│
└───────────────────────

<b>Commands:</b>
<code>.survival</code> - Cek status
<code>.eat protein_bar</code> - Makan
<code>.drink purified_water</code> - Minum
<code>.rest 2</code> - Istirahat 2 jam
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "rpgmenu" }]
          ],
        },
      });
    }
  });

  // RPG Gacha Menu
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "rpg_gacha") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🎰 <b>GACHA SYSTEM</b>  ║
╚══════════════════════════════════╝

<i>"Feeling lucky, choom? Try your fate."</i>

┌─「 🎫 <b>AVAILABLE BANNERS</b> 」
│
│ 🎰 <b>Standard Banner</b>
│   └ Cost: €$500
│   └ <code>.gacha standard</code>
│
│ 💎 <b>Premium Banner</b>
│   └ Cost: 💎10 Diamonds
│   └ <code>.gacha premium</code>
│   └ Higher epic/legendary rates!
│
│ ⚔️ <b>Weapon Banner</b>
│   └ Cost: €$1000
│   └ <code>.gacha weapon</code>
│   └ Weapons only!
│
│ 🦾 <b>Cyber Banner</b>
│   └ Cost: 💎20 Diamonds
│   └ <code>.gacha cyber</code>
│   └ Augmentations only!
│
└───────────────────────

┌─「 📊 <b>RARITY RATES</b> 」
│
│ ⚪ Common - 50%
│ 🟢 Uncommon - 30%
│ 🔵 Rare - 13%
│ 🟣 Epic - 5%
│ 🟡 Legendary - 1.8%
│ ⭐ Mythic - 0.2%
│
└───────────────────────

<i>💡 Dapatkan 💎 diamonds dari achievements!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🎰 STANDARD", switch_inline_query_current_chat: ".gacha standard" },
              { text: "💎 PREMIUM", switch_inline_query_current_chat: ".gacha premium" }
            ],
            [
              { text: "⚔️ WEAPON", switch_inline_query_current_chat: ".gacha weapon" },
              { text: "🦾 CYBER", switch_inline_query_current_chat: ".gacha cyber" }
            ],
            [{ text: "⬅️ KEMBALI", callback_data: "rpgmenu" }]
          ],
        },
      });
    }
  });

  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "rpg_help") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  ❓ <b>CYBERPUNK RPG HELP</b>  ║
╚══════════════════════════════════╝

<b>🎮 CARA BERMAIN:</b>

1️⃣ <b>Buat karakter:</b>
   <code>.daftar V netrunner</code>
   <i>Pilih class: netrunner, solo, techie, medtech, nomad, corpo, fixer, streetkid</i>

2️⃣ <b>Cek status survival:</b>
   <code>.survival</code>
   <i>Jaga Hunger, Thirst, Stamina!</i>

3️⃣ <b>Pergi adventure:</b>
   <code>.adv gang_alley</code>
   <i>Kalahkan musuh → XP & €$</i>

4️⃣ <b>Makan & Minum:</b>
   <code>.eat protein_bar</code>
   <code>.drink purified_water</code>
   <i>Jaga survival stats!</i>

5️⃣ <b>Istirahat:</b>
   <code>.rest 2</code>
   <i>Restore stamina & sanity</i>

6️⃣ <b>Beli di Black Market:</b>
   <code>.shop</code>
   <code>.buy stimpack</code>

7️⃣ <b>Equip gear:</b>
   <code>.equip katana</code>

8️⃣ <b>Daily reward:</b>
   <code>.daily</code>

9️⃣ <b>Lucky draw:</b>
   <code>.gacha standard</code>

<b>📌 SURVIVAL TIPS:</b>
• ⚡ Low stamina = Can't adventure
• 🍖 Low hunger = ATK debuff
• 💧 Low thirst = DEF debuff
• 🧠 Low sanity = Random debuffs
• 🦾 Low humanity = Cyberpsychosis risk

<b>🎭 QUICK COMMANDS:</b>
<code>.profile</code> • <code>.survival</code> • <code>.inventory</code>
<code>.shop</code> • <code>.gacha</code> • <code>.leaderboard</code>

<i>💀 "Wake up, Samurai. We have a city to burn."</i>
<i>© 2077 Schnuffelll Entertainment</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "⬅️ KEMBALI", callback_data: "rpgmenu" }]
          ],
        },
      });
    }
  });

  // ═══════════════════════════════════════════════════════════════
  // INSTALL PROTECT MENU
  // ═══════════════════════════════════════════════════════════════
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "installprotectmenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🛡️ <b>INSTALL PROTECT</b>  ║
╠══════════════════════════════════╣
║  Proteksi VPS dari Serangan  ║
╚══════════════════════════════════╝

<blockquote expandable>
┌─「 🔐 <b>SECURITY SCRIPTS</b> 」
│
│ <code>/installprotect ipvps,pwvps</code>
│   └ Install script proteksi lengkap
│   └ Anti-DDoS, Firewall, Fail2ban
│   └ Port knocking, SSH hardening
│
│ <code>/installcsf ipvps,pwvps</code>
│   └ Install CSF Firewall
│   └ ConfigServer Security & Firewall
│
│ <code>/installddos ipvps,pwvps</code>
│   └ Install Anti-DDoS script
│   └ Protect dari serangan DDoS
│
│ <code>/installf2b ipvps,pwvps</code>
│   └ Install Fail2ban
│   └ Block IP yang mencoba brute force
│
└───────────────────────
</blockquote>

<blockquote expandable>
┌─「 🔒 <b>CLOUDFLARE</b> 」
│
│ <code>/antiddos on</code>
│   └ Aktifkan Under Attack Mode
│
│ <code>/antiddos off</code>
│   └ Nonaktifkan Under Attack Mode
│
└───────────────────────
</blockquote>

<i>💡 Pastikan VPS sudah terinstall panel sebelum install protect!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🛡️ INSTALL ALL", switch_inline_query_current_chat: "/installprotect " },
              { text: "🔥 FIREWALL", switch_inline_query_current_chat: "/installcsf " }
            ],
            [
              { text: "🚫 ANTI-DDOS", switch_inline_query_current_chat: "/installddos " },
              { text: "🔒 FAIL2BAN", switch_inline_query_current_chat: "/installf2b " }
            ],
            [
              { text: "⬅️ KEMBALI", callback_data: "back" }
            ]
          ],
        },
      });
    }
  });

  // ═══════════════════════════════════════════════════════════════
  // UNINSTALL PROTECT MENU
  // ═══════════════════════════════════════════════════════════════
  bot.on("callback_query", (callbackQuery) => {
    if (callbackQuery.data === "uninstallprotectmenu") {
      bot.answerCallbackQuery(callbackQuery.id);
      const text = `
╔══════════════════════════════════╗
║  🗑️ <b>UNINSTALL PROTECT</b>  ║
╠══════════════════════════════════╣
║  Hapus Script Proteksi VPS  ║
╚══════════════════════════════════╝

<blockquote expandable>
┌─「 ⚠️ <b>UNINSTALL SCRIPTS</b> 」
│
│ <code>/uninstallprotect ipvps,pwvps</code>
│   └ Hapus semua script proteksi
│   └ Reset ke default
│
│ <code>/uninstallcsf ipvps,pwvps</code>
│   └ Hapus CSF Firewall
│
│ <code>/uninstallf2b ipvps,pwvps</code>
│   └ Hapus Fail2ban
│
└───────────────────────
</blockquote>

<blockquote>
⚠️ <b>PERINGATAN!</b>
Menghapus script proteksi akan membuat VPS lebih rentan terhadap serangan!
Pastikan kamu tau apa yang kamu lakukan.
</blockquote>

<i>💡 Uninstall hanya jika diperlukan!</i>
`;
      bot.editMessageText(text, {
        chat_id: callbackQuery.message.chat.id,
        message_id: callbackQuery.message.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🗑️ UNINSTALL ALL", switch_inline_query_current_chat: "/uninstallprotect " }
            ],
            [
              { text: "❌ HAPUS CSF", switch_inline_query_current_chat: "/uninstallcsf " },
              { text: "❌ HAPUS F2B", switch_inline_query_current_chat: "/uninstallf2b " }
            ],
            [
              { text: "⬅️ KEMBALI", callback_data: "back" }
            ]
          ],
        },
      });
    }
  });
}