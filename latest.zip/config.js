const settings = {
  token: '8522096996:AAFlxkE231FMZbbOIcWldhe1mCeiD7iJzOs', // token dari @BotFather
    
  ownerId: 1126396317, // user id
  dev: 'schnuffelll', // wajib username tele
  // --- GITHUB DATABASE ---
  // (Data rahasia sudah dipindah ke schnuffelll.js dan addusr.js)
  
  dana: '08123456789', // nomer dana
  namaDana: 'Belum Diatur', // nama
    
  chUsn: '@schnuffelllll', // ch tele
  
  exPGroupId: "-1003107203262", // id group
  exGroupId: "-1003107203262", // id group
    
  hostname: "vps", // hostname vps
  cfApiToken: "oWm4SD2iMGwLk_MQryXVlOiiBovAlVQxtoADiet7", // api token cloudflare
  cfZoneId: "1b662cae2a8214a8468c97fb552070d0", // zone id domain cf
    
  apiDigitalOcean: "dop_v1_b7656e853a301a6a9ca205ddfba6affc810045abdb02c756e1b3c823039c6f5d", // apikey do
    
  apiDigitalOcean2: "-", // apikey do 2
  
  apiDigitalOcean3: "-", // apikey do 3
  
  pp: 'https://img1.pixhost.to/images/10634/667901401_schnuffelll-md.png', // file catbox foto
  ppVid: 'https://files.catbox.moe/4nfh55.mp4', // file catbox video
  panel: 'https://files.catbox.moe/w97di8.jpg', // foto panel

  qris: 'https://files.catbox.moe/fqsum3.jpg', // qris

  // --- DATA PANEL ---
  // (Semua data panel dipindah ke db/panel_settings.json)
  // (Gunakan /seturl, /setplta, /setpltc untuk mengatur)

  eggs: 15,
loc: 1,
};

module.exports = settings;