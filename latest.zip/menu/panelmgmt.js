/**
 * ═══════════════════════════════════════════════════════════════════════════════════════
 *  📦 SCHNUFFELLL BOT - PANEL MANAGEMENT v8.0
 *  Commands for managing Pterodactyl panels (multi-panel support)
 *  
 *  Commands:
 *  /panelinfo          - Info panel & license
 *  /panelusers         - List users
 *  /panelservers       - List servers
 *  /panelnodes         - List nodes
 *  /panelstats         - Statistics
 *  /panelhealth        - Health check
 *  /panelrestart       - Restart panel services (SSH)
 *  /panelbackup        - Backup panel (SSH)
 *  /panelclear         - Clear cache (SSH)
 *  
 *  @author @schnuffelll
 *  @version 8.0
 * ═══════════════════════════════════════════════════════════════════════════════════════
 */

const axios = require('axios');
const fs = require('fs');
const { loadJsonData, saveJsonData } = require('../lib/function');
const settings = require('../config.js');

module.exports = (bot) => {

    console.log('[PANEL] 📦 Panel Management Module v8.0 loaded');

    const OWNER_FILE = './db/users/adminID.json';
    const PREMIUM_FILE = './db/users/premiumUsers.json';

    // Helper: Check access
    function hasAccess(userId) {
        const owners = loadJsonData(OWNER_FILE);
        const premium = loadJsonData(PREMIUM_FILE);
        return owners.includes(String(userId)) || premium.includes(String(userId));
    }

    // Helper: Get panel config
    function getPanelConfig(version = 1) {
        const versions = {
            1: { domain: settings.domain, key: settings.plta },
            2: { domain: settings.domainV2, key: settings.pltaV2 },
            3: { domain: settings.domainV3, key: settings.pltaV3 },
            4: { domain: settings.domainV4, key: settings.pltaV4 },
            5: { domain: settings.domainV5, key: settings.pltaV5 }
        };
        return versions[version] || versions[1];
    }

    // Helper: App API
    async function appApi(endpoint, version = 1) {
        const config = getPanelConfig(version);
        const url = `https://${config.domain}/api/application${endpoint}`;
        const headers = {
            'Authorization': `Bearer ${config.key}`,
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };
        const response = await axios.get(url, { headers, timeout: 10000 });
        return response.data;
    }

    // ═══════════════════════════════════════════════════════════════════════════════
    // /panelinfo [version] - Panel Information
    // ═══════════════════════════════════════════════════════════════════════════════
    bot.onText(/^\/panelinfo(?:\s+(\d))?$/i, async (msg, match) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id.toString();

        if (!hasAccess(userId)) {
            return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ/ᴘʀᴇᴍɪᴜᴍ!');
        }

        const version = match[1] ? parseInt(match[1]) : 1;
        const config = getPanelConfig(version);
        const wait = await bot.sendMessage(chatId, `⏳ Checking panel v${version}...`);

        try {
            // Fetch concurrent data
            const [users, servers, nodes] = await Promise.all([
                appApi('/users', version),
                appApi('/servers', version),
                appApi('/nodes', version)
            ]);

            const text = `
📦 <b>PANEL INFORMATION v${version}</b>
<code>━━━━━━━━━━━━━━━━━━━━━━</code>

<blockquote>
🌐 <b>Domain:</b> ${config.domain}
📊 <b>Stats:</b>
┣ 👥 Users: ${users.meta.pagination.total}
┣ 🖥️ Servers: ${servers.meta.pagination.total}
┗ 📡 Nodes: ${nodes.meta.pagination.total}

✅ <b>Status:</b> ONLINE
🕒 <b>Checked:</b> ${new Date().toLocaleString('id-ID')}
</blockquote>
`;

            bot.editMessageText(text, {
                chat_id: chatId,
                message_id: wait.message_id,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '👥 Users', callback_data: `pnl_users_${version}` },
                            { text: '🖥️ Servers', callback_data: `pnl_servers_${version}` }
                        ],
                        [
                            { text: '📡 Nodes', callback_data: `pnl_nodes_${version}` },
                            { text: '🏥 Health', callback_data: `pnl_health_${version}` }
                        ]
                    ]
                }
            });

        } catch (error) {
            bot.editMessageText(`❌ <b>Panel v${version} Error:</b>\n\n${error.message}`, {
                chat_id: chatId,
                message_id: wait.message_id,
                parse_mode: 'HTML'
            });
        }
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // /panelhealth [version] - Check system health
    // ═══════════════════════════════════════════════════════════════════════════════
    bot.onText(/^\/panelhealth(?:\s+(\d))?$/i, async (msg, match) => {
        const chatId = msg.chat.id;
        const version = match[1] ? parseInt(match[1]) : 1;

        try {
            const start = Date.now();
            await appApi('/users?per_page=1', version);
            const latency = Date.now() - start;

            let status = '🟢 Excellent';
            if (latency > 500) status = '🟡 Good';
            if (latency > 1500) status = '🟠 Lagging';
            if (latency > 3000) status = '🔴 Slow';

            bot.sendMessage(chatId, `🏥 <b>Panel Health v${version}</b>\n\n📶 Latency: ${latency}ms\n📊 Status: ${status}`, { parse_mode: 'HTML' });
        } catch (e) {
            bot.sendMessage(chatId, `🏥 <b>Panel Health v${version}</b>\n\n❌ Status: OFFLINE/ERROR\n⚠ Error: ${e.message}`, { parse_mode: 'HTML' });
        }
    });

    // ═══════════════════════════════════════════════════════════════════════════════
    // Callback Query Handler
    // ═══════════════════════════════════════════════════════════════════════════════
    bot.on('callback_query', async (query) => {
        const data = query.data;
        const chatId = query.message.chat.id;

        if (!data.startsWith('pnl_')) return;

        const parts = data.split('_');
        const action = parts[1];
        const version = parseInt(parts[2]) || 1;

        if (action === 'users') {
            try {
                const res = await appApi('/users?sort=-created_at', version);
                let text = `👥 <b>Recent Users v${version}</b>\n\n`;
                res.data.slice(0, 10).forEach(u => {
                    text += `• <b>${u.attributes.username}</b> (${u.attributes.email})\n`;
                });
                bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
            } catch (e) {
                bot.sendMessage(chatId, `❌ Error: ${e.message}`);
            }
        }

        if (action === 'servers') {
            try {
                const res = await appApi('/servers?sort=-created_at', version);
                let text = `🖥️ <b>Recent Servers v${version}</b>\n\n`;
                res.data.slice(0, 10).forEach(s => {
                    text += `• <b>${s.attributes.name}</b> (${s.attributes.user})\n`;
                });
                bot.sendMessage(chatId, text, { parse_mode: 'HTML' });
            } catch (e) {
                bot.sendMessage(chatId, `❌ Error: ${e.message}`);
            }
        }

        bot.answerCallbackQuery(query.id);
    });

};
